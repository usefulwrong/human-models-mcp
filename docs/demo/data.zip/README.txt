UsefulWrong / human-models-mcp 0.7.0 public palm demo

This contains the exact renderer-exported source.zip, unchanged, plus locks and license notices. Extract source.zip to inspect all states and 700-actuator traces.
Scenario: pushup_palms 1.5.0, chest_full. Control: assisted_muscle, external residual joint assistance USED; muscle-only NOT_ACHIEVED. The two wrist lower bounds are -0.930016 rad rather than -0.6 rad. This is a literature-informed derivative, not participant calibration.
Run: 9ed1e5d7-40b9-4d4c-96f8-8fcc98e6ac1b
Original source.zip SHA-256: f793e08da58d267de29256e17e9f954c9aaeb786689aef4001372825cdec2fe7

Reproduce with the public source checkout, locked downloads and the commands in docs/demo/README.md. Model assets are downloaded from the pinned official Menagerie revision, not embedded here. No clinical/human experimental validation or patient data. Read all retained notices; wrapper MIT does not relicense the Apache-2.0 model derivatives.
